insert into veiculo (id, modelo, marca, cor, ano_de_fabricacao, litro, Kilom_Lit, autonomia) values (-1, 'civic', 'Honda', 'prata', 2019, 10, 12, 120);
insert into veiculo (id, modelo, marca, cor, ano_de_fabricacao, litro, Kilom_Lit, autonomia) values (-2, 'jetta', 'Volkswagen', 'cinza', 2017, 10, 12, 120);
insert into veiculo (id, modelo, marca, cor, ano_de_fabricacao, litro, Kilom_Lit, autonomia) values (-3, 'elantra', 'Hyundai', 'vermelho', 2020, 10, 12, 120);
insert into veiculo (id, modelo, marca, cor, ano_de_fabricacao, litro, Kilom_Lit, autonomia) values (-4, 'corolla', 'Toyota', 'branco', 2015, 10, 12, 120);

INSERT INTO USUARIO (id, login, senha, adm) VALUES (1, 'admin', 'admin', true);
INSERT INTO USUARIO (id, login, senha, adm) VALUES (2, 'Murilo', 'mumu21', false);
INSERT INTO USUARIO (id, login, senha, adm) VALUES (3, 'Bossini', 'rb15', false);