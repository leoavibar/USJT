package br.usjt.hellospringboot.model;

public class Calculadora {
	
	public double calculo (Double litros, Double KilomLit) {
	return litros * KilomLit;
	}
	
}
